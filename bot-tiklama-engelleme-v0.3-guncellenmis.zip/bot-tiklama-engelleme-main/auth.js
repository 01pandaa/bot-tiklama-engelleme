const SUPABASE_URL = 'https://snfjcdknsfwjnxrggypc.supabase.co';
const SUPABASE_KEY = 'sb_publishable_q9b5q9JV-5Zd6FLY13rWxQ_o2dMvN-_';

const client = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
window.clickShieldClient = client;

function showMessage(text, isError = false) {
  const message = document.getElementById('message');
  if (!message) return;
  message.textContent = text;
  message.className = `auth-message ${isError ? 'error' : 'success'}`;
  message.setAttribute('aria-live', 'polite');
}

function setFormBusy(form, busy, label) {
  const button = form?.querySelector('button[type="submit"]');
  if (!button) return;
  button.disabled = busy;
  if (busy) button.dataset.originalLabel = button.textContent;
  button.textContent = busy ? label : (button.dataset.originalLabel || button.textContent);
}

const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const email = document.getElementById('email')?.value.trim() || '';
    const password = document.getElementById('password')?.value || '';
    setFormBusy(loginForm, true, 'Giriş yapılıyor…');
    showMessage('Giriş yapılıyor…');

    const { error } = await client.auth.signInWithPassword({ email, password });
    if (error) {
      showMessage(error.message || 'Giriş yapılamadı.', true);
      setFormBusy(loginForm, false);
      return;
    }

    location.replace('index.html');
  });
}

const signupForm = document.getElementById('signupForm');
if (signupForm) {
  signupForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const fullName = document.getElementById('fullName')?.value.trim() || '';
    const email = document.getElementById('email')?.value.trim() || '';
    const password = document.getElementById('password')?.value || '';
    setFormBusy(signupForm, true, 'Hesap oluşturuluyor…');
    showMessage('Hesap oluşturuluyor…');

    const { data, error } = await client.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } }
    });

    if (error) {
      showMessage(error.message || 'Hesap oluşturulamadı.', true);
      setFormBusy(signupForm, false);
      return;
    }

    if (data.session) {
      location.replace('index.html');
      return;
    }

    showMessage('Hesabın oluşturuldu. E-posta adresine gelen doğrulama bağlantısını aç, sonra giriş yap.');
    setFormBusy(signupForm, false);
  });
}
